package com.software.helloworld;

/**
 * Created by kshtz on 1/28/2016.
 */
public class Student {
    String name;
    String studentId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public Student(){

    }
}
